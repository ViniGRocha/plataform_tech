import express from 'express';
import chatBotController from './controller/chatBotController';

export const routerChatBot = express.Router();
routerChatBot.post('/chat', chatBotController);

